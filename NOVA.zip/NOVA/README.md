# Nova AI - Voice Assistant App

A complete Android voice assistant app that replicates the Nova AI experience with futuristic UI, conversational AI, and smart automation features.

## 🎯 Features

- **Wake Word Activation**: Say "Nova" to activate the assistant
- **Dual Personalities**: Tokyo (warm, empathetic) and Toronto (confident, direct)
- **Voice Recognition**: Real-time speech-to-text conversion
- **AI Conversations**: Powered by Gemini Pro API
- **Smart Actions**: Call, message, music, weather, navigation
- **Animated UI**: Futuristic dark theme with neon accents
- **Voice Visualizer**: Real-time audio visualization
- **Background Service**: Continuous wake word detection
- **Floating Widget**: Quick access overlay

## 🛠️ Tech Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose
- **Architecture**: MVVM with Hilt DI
- **AI Integration**: Gemini Pro API
- **Speech**: Android SpeechRecognizer & TTS
- **Wake Word**: Picovoice Porcupine (with fallback)
- **Animations**: Lottie, Compose Animations

## 📋 Setup Instructions

### 1. Prerequisites
- Android Studio Arctic Fox or later
- Android SDK 24+ (Android 7.0)
- Gemini Pro API key
- Picovoice access key (optional)

### 2. API Keys Setup
1. Get a Gemini Pro API key from [Google AI Studio](https://makersuite.google.com/)
2. Replace `YOUR_GEMINI_API_KEY` in `AIProcessor.kt` with your actual key
3. (Optional) Get Picovoice access key for wake word detection

### 3. Build & Run
```bash
git clone <repository-url>
cd nova-ai
./gradlew assembleDebug
```

### 4. Permissions
The app requires the following permissions:
- `RECORD_AUDIO` - Voice recognition
- `CALL_PHONE` - Making calls
- `SEND_SMS` - Sending messages
- `ACCESS_FINE_LOCATION` - Location services
- `SYSTEM_ALERT_WINDOW` - Floating widget

## 🎨 UI Components

### Main Screen
- **Animated Avatar**: Personality-based avatar with glow effects
- **Voice Visualizer**: Real-time audio bars
- **Mic Button**: Animated button with ripple effects
- **Conversation Display**: Typewriter text animation

### Animations
- **Pulsing Avatar**: During voice interactions
- **Ripple Effects**: On mic button press
- **Typing Animation**: For AI responses
- **Voice Bars**: Audio visualization

## 🧠 AI Integration

### Gemini Pro Setup
```kotlin
private val generativeModel = GenerativeModel(
    modelName = "gemini-pro",
    apiKey = "YOUR_GEMINI_API_KEY"
)
```

### Personality System
- **Tokyo**: Warm, empathetic responses with higher pitch TTS
- **Toronto**: Confident, direct responses with lower pitch TTS

## 📱 Smart Actions

The app can execute various smart actions:

### Voice Commands
- "Call Mom" → Opens phone dialer
- "Message John" → Opens messaging app
- "Play music" → Launches music player
- "What's the weather?" → Shows weather info
- "Navigate to home" → Opens maps

### Action Processing
1. Speech recognition converts voice to text
2. AI processor analyzes intent
3. Action handler executes appropriate Android intent
4. TTS provides confirmation

## 🔧 Architecture

```
├── core/
│   ├── VoiceEngine.kt          # Speech recognition & TTS
│   ├── AIProcessor.kt          # Gemini integration
│   ├── ActionHandler.kt        # Smart action execution
│   └── WakeWordDetector.kt     # Wake word detection
├── presentation/
│   ├── screen/                 # Compose screens
│   ├── component/              # Reusable UI components
│   ├── theme/                  # App theming
│   └── viewmodel/              # ViewModels
├── data/
│   └── model/                  # Data models
├── service/                    # Background services
└── di/                         # Dependency injection
```

## 🎭 Personality Switching

Users can switch between personalities:
- **Tap the personality switcher** in the top bar
- **Voice command**: "Switch to Tokyo/Toronto"
- **Gesture**: Swipe on avatar (future enhancement)

## 🔊 Voice Features

### Text-to-Speech
- Emotional speech synthesis
- Personality-based voice characteristics
- Adjustable speed and pitch

### Speech Recognition
- Real-time voice recognition
- Partial results for immediate feedback
- Error handling and retry logic

## 🌟 Future Enhancements

- [ ] Custom wake word training
- [ ] Voice authentication
- [ ] Multi-language support
- [ ] Advanced emotion detection
- [ ] Smart home integration
- [ ] Conversation memory
- [ ] Custom voice cloning

## 🐛 Troubleshooting

### Common Issues
1. **Microphone not working**: Check permissions
2. **Wake word not detecting**: Ensure background service is running
3. **AI not responding**: Verify Gemini API key
4. **Floating widget not showing**: Enable overlay permission

### Debug Mode
Enable debug logging in `VoiceEngine.kt` for detailed logs.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📞 Support

For support and questions:
- Create an issue on GitHub
- Check the troubleshooting section
- Review the documentation

---

**Note**: This app replicates the Nova AI experience shown in Instagram reels. Make sure to replace placeholder API keys with actual keys before building.
