package com.nova.ai

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import com.nova.ai.presentation.navigation.NovaNavigation
import com.nova.ai.presentation.theme.NovaAITheme
import com.nova.ai.service.VoiceAssistantService
import com.nova.ai.service.WakeWordService
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            startServices()
        } else {
            // Handle permission denial - could show a dialog or navigate to settings
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        checkAndRequestPermissions()
        
        setContent {
            NovaAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NovaNavigation()
                }
            }
        }
    }
    
    private fun checkAndRequestPermissions() {
        val requiredPermissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.SYSTEM_ALERT_WINDOW
        )
        
        val permissionsToRequest = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PermissionChecker.PERMISSION_GRANTED
        }
        
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            startServices()
        }
    }
    
    private fun startServices() {
        // Start voice assistant service
        val voiceServiceIntent = Intent(this, VoiceAssistantService::class.java)
        startForegroundService(voiceServiceIntent)
        
        // Start wake word service
        val wakeWordServiceIntent = Intent(this, WakeWordService::class.java)
        startForegroundService(wakeWordServiceIntent)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        // Stop services when activity is destroyed
        stopService(Intent(this, VoiceAssistantService::class.java))
        stopService(Intent(this, WakeWordService::class.java))
    }
}
