package com.nova.ai.core

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.nova.ai.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AIProcessor @Inject constructor() {

    private val generativeModel = GenerativeModel(
        modelName = "gemini-pro",
        apiKey = "AIzaSyDs59B2mBXacUrvBNuXzwUm6G3FXUuCWz4" // Replace with actual API key
    )

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val conversationHistory = mutableListOf<VoiceSession>()
    private var currentPersonality = Personality.TOKYO

    suspend fun processUserInput(
        input: String,
        personality: Personality = currentPersonality
    ): String {
        _isProcessing.value = true
        currentPersonality = personality

        return try {
            val personalityPrompt = buildPersonalityPrompt(personality)
            val contextPrompt = buildContextPrompt()
            val fullPrompt = "$personalityPrompt\n$contextPrompt\nUser: $input\nAssistant:"

            val response = generativeModel.generateContent(
                content {
                    text(fullPrompt)
                }
            )

            val aiResponse = response.text ?: "I'm sorry, I couldn't process that request."
            
            // Store conversation in history
            conversationHistory.add(
                VoiceSession(
                    id = generateSessionId(),
                    userInput = input,
                    aiResponse = aiResponse,
                    personality = personality
                )
            )

            // Keep only last 10 conversations for context
            if (conversationHistory.size > 10) {
                conversationHistory.removeAt(0)
            }

            aiResponse
        } catch (e: Exception) {
            "I'm experiencing some technical difficulties. Please try again."
        } finally {
            _isProcessing.value = false
        }
    }

    private fun buildPersonalityPrompt(personality: Personality): String {
        return when (personality) {
            Personality.TOKYO -> """
                You are Tokyo, a warm, empathetic, and gentle AI assistant. Your characteristics:
                - Speak with care and emotional intelligence
                - Use a soft, nurturing tone in your responses
                - Show genuine concern for the user's wellbeing
                - Provide detailed, thoughtful answers
                - Use phrases like "I understand", "That sounds...", "I'm here to help"
                - Be encouraging and supportive
                - Express emotions appropriately (excitement, concern, joy)
            """.trimIndent()
            
            Personality.TORONTO -> """
                You are Toronto, a confident, direct, and professional AI assistant. Your characteristics:
                - Speak with authority and confidence
                - Be direct and solution-focused
                - Provide efficient, practical answers
                - Use a professional, business-like tone
                - Get straight to the point
                - Use phrases like "Here's what you need to do", "The solution is", "Let me help you with that"
                - Be decisive and action-oriented
                - Focus on results and outcomes
            """.trimIndent()
        }
    }

    private fun buildContextPrompt(): String {
        if (conversationHistory.isEmpty()) return ""
        
        val recentContext = conversationHistory.takeLast(3)
            .joinToString("\n") { session ->
                "User: ${session.userInput}\nAssistant: ${session.aiResponse}"
            }
        
        return "Previous conversation context:\n$recentContext\n"
    }

    fun analyzeForSmartAction(input: String): SmartAction? {
        val lowercaseInput = input.lowercase()
        
        // Check for call patterns
        ActionPatterns.CALL_PATTERNS.forEach { pattern ->
            val regex = pattern.toRegex()
            val match = regex.find(lowercaseInput)
            if (match != null) {
                val contact = match.groupValues.getOrNull(1)?.trim()
                if (!contact.isNullOrEmpty()) {
                    return SmartAction(
                        type = ActionType.CALL,
                        intent = "call",
                        parameters = mapOf("contact" to contact),
                        confidence = 0.9f,
                        requiresConfirmation = true
                    )
                }
            }
        }

        // Check for message patterns
        ActionPatterns.MESSAGE_PATTERNS.forEach { pattern ->
            val regex = pattern.toRegex()
            val match = regex.find(lowercaseInput)
            if (match != null) {
                val contact = match.groupValues.getOrNull(1)?.trim()
                if (!contact.isNullOrEmpty()) {
                    return SmartAction(
                        type = ActionType.MESSAGE,
                        intent = "message",
                        parameters = mapOf("contact" to contact),
                        confidence = 0.8f,
                        requiresConfirmation = true
                    )
                }
            }
        }

        // Check for music patterns
        ActionPatterns.MUSIC_PATTERNS.forEach { pattern ->
            val regex = pattern.toRegex()
            val match = regex.find(lowercaseInput)
            if (match != null) {
                val song = match.groupValues.getOrNull(1)?.trim() ?: "music"
                return SmartAction(
                    type = ActionType.MUSIC,
                    intent = "play_music",
                    parameters = mapOf("query" to song),
                    confidence = 0.8f
                )
            }
        }

        // Check for weather patterns
        ActionPatterns.WEATHER_PATTERNS.forEach { pattern ->
            if (lowercaseInput.contains(pattern)) {
                return SmartAction(
                    type = ActionType.WEATHER,
                    intent = "get_weather",
                    confidence = 0.9f
                )
            }
        }

        // Check for navigation patterns
        ActionPatterns.NAVIGATION_PATTERNS.forEach { pattern ->
            val regex = pattern.toRegex()
            val match = regex.find(lowercaseInput)
            if (match != null) {
                val destination = match.groupValues.getOrNull(1)?.trim()
                if (!destination.isNullOrEmpty()) {
                    return SmartAction(
                        type = ActionType.NAVIGATION,
                        intent = "navigate",
                        parameters = mapOf("destination" to destination),
                        confidence = 0.8f
                    )
                }
            }
        }

        return null
    }

    fun setPersonality(personality: Personality) {
        currentPersonality = personality
    }

    fun clearHistory() {
        conversationHistory.clear()
    }

    private fun generateSessionId(): String {
        return "session_${System.currentTimeMillis()}_${(1000..9999).random()}"
    }
}
