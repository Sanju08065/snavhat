package com.nova.ai.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import com.nova.ai.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ActionHandler @Inject constructor(
    private val context: Context
) {

    suspend fun executeAction(action: SmartAction): ActionResult {
        return withContext(Dispatchers.IO) {
            try {
                when (action.type) {
                    ActionType.CALL -> handleCall(action)
                    ActionType.MESSAGE -> handleMessage(action)
                    ActionType.MUSIC -> handleMusic(action)
                    ActionType.WEATHER -> handleWeather(action)
                    ActionType.NAVIGATION -> handleNavigation(action)
                    ActionType.APP_LAUNCH -> handleAppLaunch(action)
                    ActionType.WEB_SEARCH -> handleWebSearch(action)
                    else -> ActionResult(false, "Action type not supported")
                }
            } catch (e: Exception) {
                ActionResult(false, "Error executing action: ${e.message}")
            }
        }
    }

    private fun handleCall(action: SmartAction): ActionResult {
        val contact = action.parameters["contact"] ?: return ActionResult(false, "No contact specified")
        
        return try {
            val phoneNumber = findContactPhoneNumber(contact)
            if (phoneNumber != null) {
                val callIntent = Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$phoneNumber")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(callIntent)
                ActionResult(true, "Calling $contact")
            } else {
                // Try direct dialing if it looks like a phone number
                if (contact.matches(Regex("[0-9+\\-\\s()]+"))) {
                    val callIntent = Intent(Intent.ACTION_CALL).apply {
                        data = Uri.parse("tel:$contact")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(callIntent)
                    ActionResult(true, "Calling $contact")
                } else {
                    ActionResult(false, "Contact '$contact' not found")
                }
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to make call: ${e.message}")
        }
    }

    private fun handleMessage(action: SmartAction): ActionResult {
        val contact = action.parameters["contact"] ?: return ActionResult(false, "No contact specified")
        val message = action.parameters["message"] ?: "Hello from Nova AI"
        
        return try {
            val phoneNumber = findContactPhoneNumber(contact)
            if (phoneNumber != null) {
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
                ActionResult(true, "Message sent to $contact")
            } else {
                // Open messaging app with contact search
                val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:")
                    putExtra("sms_body", message)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(smsIntent)
                ActionResult(true, "Opening messaging app")
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to send message: ${e.message}")
        }
    }

    private fun handleMusic(action: SmartAction): ActionResult {
        val query = action.parameters["query"] ?: "music"
        
        return try {
            // Try Spotify first
            val spotifyIntent = Intent().apply {
                action = "android.media.action.MEDIA_PLAY_FROM_SEARCH"
                component = android.content.ComponentName(
                    "com.spotify.music",
                    "com.spotify.music.MainActivity"
                )
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            if (isAppInstalled("com.spotify.music")) {
                context.startActivity(spotifyIntent)
                ActionResult(true, "Playing '$query' on Spotify")
            } else {
                // Fallback to default music player
                val musicIntent = Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH").apply {
                    putExtra("query", query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(musicIntent)
                ActionResult(true, "Playing '$query'")
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to play music: ${e.message}")
        }
    }

    private fun handleWeather(action: SmartAction): ActionResult {
        return try {
            // Open weather app or web search
            val weatherIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", "weather")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(weatherIntent)
            ActionResult(true, "Opening weather information")
        } catch (e: Exception) {
            ActionResult(false, "Failed to get weather: ${e.message}")
        }
    }

    private fun handleNavigation(action: SmartAction): ActionResult {
        val destination = action.parameters["destination"] ?: return ActionResult(false, "No destination specified")
        
        return try {
            val mapsIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("geo:0,0?q=$destination")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            if (isAppInstalled("com.google.android.apps.maps")) {
                mapsIntent.setPackage("com.google.android.apps.maps")
            }
            
            context.startActivity(mapsIntent)
            ActionResult(true, "Navigating to $destination")
        } catch (e: Exception) {
            ActionResult(false, "Failed to start navigation: ${e.message}")
        }
    }

    private fun handleAppLaunch(action: SmartAction): ActionResult {
        val appName = action.parameters["app"] ?: return ActionResult(false, "No app specified")
        
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(appName)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                ActionResult(true, "Launching $appName")
            } else {
                ActionResult(false, "App '$appName' not found")
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to launch app: ${e.message}")
        }
    }

    private fun handleWebSearch(action: SmartAction): ActionResult {
        val query = action.parameters["query"] ?: return ActionResult(false, "No search query specified")
        
        return try {
            val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(searchIntent)
            ActionResult(true, "Searching for '$query'")
        } catch (e: Exception) {
            ActionResult(false, "Failed to perform web search: ${e.message}")
        }
    }

    private fun findContactPhoneNumber(contactName: String): String? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$contactName%"),
            null
        )
        
        cursor?.use {
            if (it.moveToFirst()) {
                val phoneNumberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(phoneNumberIndex)
            }
        }
        
        return null
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: Exception) {
            false
        }
    }
}
