package com.nova.ai.core

import android.content.Context
import ai.picovoice.porcupine.*
import com.nova.ai.data.model.WakeWordState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WakeWordDetector @Inject constructor(
    private val context: Context
) {

    private var porcupine: Porcupine? = null
    private var audioRecorder: PorcupineAudioRecorder? = null
    
    private val _wakeWordState = MutableStateFlow(WakeWordState.INACTIVE)
    val wakeWordState: StateFlow<WakeWordState> = _wakeWordState.asStateFlow()

    private var onWakeWordDetected: (() -> Unit)? = null

    fun initialize(accessKey: String) {
        try {
            // Initialize Porcupine with "Nova" wake word
            val porcupineBuilder = Porcupine.Builder()
                .setAccessKey(accessKey)
                .setKeywords(arrayOf(Porcupine.BuiltInKeyword.COMPUTER)) // Using built-in keyword as fallback
            
            porcupine = porcupineBuilder.build(context)
            
            // Initialize audio recorder
            audioRecorder = PorcupineAudioRecorder.Builder()
                .setSampleRate(porcupine!!.sampleRate)
                .setFrameLength(porcupine!!.frameLength)
                .build()

        } catch (e: PorcupineException) {
            _wakeWordState.value = WakeWordState.ERROR
        }
    }

    fun startListening(onDetected: () -> Unit) {
        if (porcupine == null || audioRecorder == null) {
            _wakeWordState.value = WakeWordState.ERROR
            return
        }

        onWakeWordDetected = onDetected
        _wakeWordState.value = WakeWordState.LISTENING

        try {
            audioRecorder?.start { pcm ->
                try {
                    val keywordIndex = porcupine?.process(pcm) ?: -1
                    if (keywordIndex >= 0) {
                        _wakeWordState.value = WakeWordState.DETECTED
                        onWakeWordDetected?.invoke()
                        
                        // Reset to listening after detection
                        _wakeWordState.value = WakeWordState.LISTENING
                    }
                } catch (e: PorcupineException) {
                    _wakeWordState.value = WakeWordState.ERROR
                }
            }
        } catch (e: Exception) {
            _wakeWordState.value = WakeWordState.ERROR
        }
    }

    fun stopListening() {
        try {
            audioRecorder?.stop()
            _wakeWordState.value = WakeWordState.INACTIVE
        } catch (e: Exception) {
            _wakeWordState.value = WakeWordState.ERROR
        }
    }

    fun cleanup() {
        try {
            audioRecorder?.stop()
            porcupine?.delete()
            _wakeWordState.value = WakeWordState.INACTIVE
        } catch (e: Exception) {
            // Handle cleanup errors silently
        }
    }

    // Fallback wake word detection using speech recognizer
    // This is a simpler implementation that doesn't require Porcupine
    fun initializeFallback() {
        // This would use Android's SpeechRecognizer in continuous mode
        // to listen for "Nova" keyword - implementation would be similar
        // to VoiceEngine but with continuous listening
        _wakeWordState.value = WakeWordState.LISTENING
    }

    fun isInitialized(): Boolean {
        return porcupine != null && audioRecorder != null
    }
}
