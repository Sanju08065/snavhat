package com.nova.ai.data.model

data class AudioVisualizationData(
    val amplitude: Float = 0f,
    val isActive: Boolean = false,
    val frequency: Float = 0f,
    val volume: Float = 0f,
    val bars: List<Float> = emptyList()
)

data class UIState(
    val voiceState: VoiceState = VoiceState.IDLE,
    val wakeWordState: WakeWordState = WakeWordState.INACTIVE,
    val currentUserInput: String = "",
    val currentAiResponse: String = "",
    val audioData: AudioVisualizationData = AudioVisualizationData(),
    val isProcessing: Boolean = false,
    val errorMessage: String? = null
)
