package com.nova.ai.data.model

import androidx.compose.ui.graphics.Color
import com.nova.ai.presentation.theme.TokyoAvatarColor
import com.nova.ai.presentation.theme.TorontoAvatarColor

enum class Personality(
    val displayName: String,
    val description: String,
    val avatarColor: Color,
    val voiceCharacteristics: String,
    val responseStyle: String
) {
    TOKYO(
        displayName = "Tokyo",
        description = "Warm, empathetic, and gentle assistant",
        avatarColor = TokyoAvatarColor,
        voiceCharacteristics = "Soft, warm, feminine voice with emotional depth",
        responseStyle = "Caring, detailed, and emotionally intelligent responses"
    ),
    TORONTO(
        displayName = "Toronto",
        description = "Confident, direct, and professional assistant",
        avatarColor = TorontoAvatarColor,
        voiceCharacteristics = "Deep, confident, masculine voice with authority",
        responseStyle = "Direct, efficient, and solution-focused responses"
    )
}


