package com.nova.ai.data.model

data class PersonalitySettings(
    val currentPersonality: Personality = Personality.TOKYO,
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val emotionalResponses: Boolean = true,
    val contextualMemory: Boolean = true
)
