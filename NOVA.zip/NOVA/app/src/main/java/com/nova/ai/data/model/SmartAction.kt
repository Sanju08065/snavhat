package com.nova.ai.data.model

enum class ActionType {
    CALL,
    MESSAGE,
    MUSIC,
    WEATHER,
    NAVIGATION,
    APP_LAUNCH,
    SYSTEM_CONTROL,
    WEB_SEARCH,
    REMINDER,
    CALENDAR,
    UNKNOWN
}

data class SmartAction(
    val type: ActionType,
    val intent: String,
    val parameters: Map<String, String> = emptyMap(),
    val confidence: Float = 0f,
    val requiresConfirmation: Boolean = false
)

data class ActionResult(
    val success: Boolean,
    val message: String,
    val data: Any? = null
)

// Predefined action patterns for intent recognition
object ActionPatterns {
    val CALL_PATTERNS = listOf(
        "call (.*)",
        "phone (.*)",
        "dial (.*)",
        "ring (.*)"
    )
    
    val MESSAGE_PATTERNS = listOf(
        "message (.*)",
        "text (.*)",
        "send (.*) a message",
        "whatsapp (.*)"
    )
    
    val MUSIC_PATTERNS = listOf(
        "play (.*)",
        "music (.*)",
        "song (.*)",
        "spotify (.*)"
    )
    
    val WEATHER_PATTERNS = listOf(
        "weather",
        "temperature",
        "forecast",
        "how's the weather"
    )
    
    val NAVIGATION_PATTERNS = listOf(
        "navigate to (.*)",
        "directions to (.*)",
        "take me to (.*)",
        "maps (.*)"
    )
}
