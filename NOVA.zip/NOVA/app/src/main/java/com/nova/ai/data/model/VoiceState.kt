package com.nova.ai.data.model

enum class VoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

enum class WakeWordState {
    INACTIVE,
    LISTENING,
    DETECTED,
    ERROR
}

data class VoiceSession(
    val id: String,
    val userInput: String = "",
    val aiResponse: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val personality: Personality = Personality.TOKYO,
    val actionExecuted: String? = null,
    val confidence: Float = 0f
)

data class AudioVisualizationData(
    val amplitude: Float = 0f,
    val frequency: FloatArray = floatArrayOf(),
    val isActive: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as AudioVisualizationData

        if (amplitude != other.amplitude) return false
        if (!frequency.contentEquals(other.frequency)) return false
        if (isActive != other.isActive) return false

        return true
    }

    override fun hashCode(): Int {
        var result = amplitude.hashCode()
        result = 31 * result + frequency.contentHashCode()
        result = 31 * result + isActive.hashCode()
        return result
    }
}
