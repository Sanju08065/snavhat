package com.nova.ai.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nova.ai.data.model.VoiceSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConversationRepository @Inject constructor(
    private val context: Context,
    private val gson: Gson = Gson()
) {
    private val conversationsFile = File(context.filesDir, "conversations.json")
    private val maxConversations = 100 // Limit to prevent excessive storage usage
    
    private val _conversations = MutableStateFlow<List<VoiceSession>>(emptyList())
    val conversations: Flow<List<VoiceSession>> = _conversations.asStateFlow()

    init {
        loadConversations()
    }

    suspend fun addConversation(conversation: VoiceSession) {
        val currentConversations = _conversations.value.toMutableList()
        currentConversations.add(conversation)

        // Keep only the most recent conversations
        if (currentConversations.size > maxConversations) {
            currentConversations.removeAt(0)
        }

        _conversations.value = currentConversations
        saveConversations()
    }

    suspend fun saveConversation(conversation: VoiceSession) {
        addConversation(conversation)
    }

    suspend fun clearConversations() {
        _conversations.value = emptyList()
        saveConversations()
    }

    suspend fun deleteConversation(conversationId: String) {
        val currentConversations = _conversations.value.toMutableList()
        currentConversations.removeAll { it.id == conversationId }
        _conversations.value = currentConversations
        saveConversations()
    }

    fun getConversationById(id: String): VoiceSession? {
        return _conversations.value.find { it.id == id }
    }

    fun getRecentConversations(limit: Int = 10): List<VoiceSession> {
        return _conversations.value.takeLast(limit)
    }

    private fun loadConversations() {
        try {
            if (conversationsFile.exists()) {
                val json = conversationsFile.readText()
                val type = object : TypeToken<List<VoiceSession>>() {}.type
                val conversations: List<VoiceSession> = gson.fromJson(json, type) ?: emptyList()
                _conversations.value = conversations
            }
        } catch (e: Exception) {
            // Handle error - start with empty list
            _conversations.value = emptyList()
        }
    }

    private fun saveConversations() {
        try {
            val json = gson.toJson(_conversations.value)
            conversationsFile.writeText(json)
        } catch (e: Exception) {
            // Handle error - could log or show user notification
        }
    }
}
