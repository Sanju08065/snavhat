package com.nova.ai.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.nova.ai.data.model.Personality
import com.nova.ai.data.model.PersonalitySettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_preferences")

@Singleton
class PreferencesRepository @Inject constructor(
    private val context: Context
) {
    private object PreferencesKeys {
        val CURRENT_PERSONALITY = stringPreferencesKey("current_personality")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val EMOTIONAL_RESPONSES = booleanPreferencesKey("emotional_responses")
        val CONTEXTUAL_MEMORY = booleanPreferencesKey("contextual_memory")
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val BACKGROUND_MODE = booleanPreferencesKey("background_mode")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val CONVERSATION_HISTORY = booleanPreferencesKey("conversation_history")
        val FIRST_LAUNCH = booleanPreferencesKey("first_launch")
    }

    val personalitySettings: Flow<PersonalitySettings> = context.dataStore.data.map { preferences ->
        PersonalitySettings(
            currentPersonality = Personality.valueOf(
                preferences[PreferencesKeys.CURRENT_PERSONALITY] ?: Personality.TOKYO.name
            ),
            voiceSpeed = preferences[PreferencesKeys.VOICE_SPEED] ?: 1.0f,
            voicePitch = preferences[PreferencesKeys.VOICE_PITCH] ?: 1.0f,
            emotionalResponses = preferences[PreferencesKeys.EMOTIONAL_RESPONSES] ?: true,
            contextualMemory = preferences[PreferencesKeys.CONTEXTUAL_MEMORY] ?: true
        )
    }

    val appSettings: Flow<AppSettings> = context.dataStore.data.map { preferences ->
        AppSettings(
            wakeWordEnabled = preferences[PreferencesKeys.WAKE_WORD_ENABLED] ?: true,
            backgroundMode = preferences[PreferencesKeys.BACKGROUND_MODE] ?: true,
            hapticFeedback = preferences[PreferencesKeys.HAPTIC_FEEDBACK] ?: true,
            conversationHistory = preferences[PreferencesKeys.CONVERSATION_HISTORY] ?: true,
            isFirstLaunch = preferences[PreferencesKeys.FIRST_LAUNCH] ?: true
        )
    }

    suspend fun updatePersonality(personality: Personality) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CURRENT_PERSONALITY] = personality.name
        }
    }

    suspend fun updateVoiceSpeed(speed: Float) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.VOICE_SPEED] = speed
        }
    }

    suspend fun updateVoicePitch(pitch: Float) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.VOICE_PITCH] = pitch
        }
    }

    suspend fun updateEmotionalResponses(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.EMOTIONAL_RESPONSES] = enabled
        }
    }

    suspend fun updateContextualMemory(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CONTEXTUAL_MEMORY] = enabled
        }
    }

    suspend fun updateWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.WAKE_WORD_ENABLED] = enabled
        }
    }

    suspend fun updateBackgroundMode(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.BACKGROUND_MODE] = enabled
        }
    }

    suspend fun updateHapticFeedback(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.HAPTIC_FEEDBACK] = enabled
        }
    }

    suspend fun updateConversationHistory(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CONVERSATION_HISTORY] = enabled
        }
    }

    suspend fun setFirstLaunchCompleted() {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.FIRST_LAUNCH] = false
        }
    }
}

data class AppSettings(
    val wakeWordEnabled: Boolean = true,
    val backgroundMode: Boolean = true,
    val hapticFeedback: Boolean = true,
    val conversationHistory: Boolean = true,
    val isFirstLaunch: Boolean = true
)
