package com.nova.ai.presentation.component

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.*
import com.nova.ai.presentation.theme.*
import kotlin.math.*

@Composable
fun AnimatedAvatar(
    personality: Personality,
    voiceState: VoiceState,
    audioData: AudioVisualizationData,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_animation")
    
    // Pulsing animation for speaking state
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    
    // Rotation animation for processing state
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    // Glow intensity based on voice state
    val glowIntensity by animateFloatAsState(
        targetValue = when (voiceState) {
            VoiceState.LISTENING -> 1f
            VoiceState.SPEAKING -> 0.8f
            VoiceState.PROCESSING -> 0.6f
            else -> 0.3f
        },
        animationSpec = tween(300),
        label = "glow_intensity"
    )

    Box(
        modifier = modifier.size(200.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer glow rings
        repeat(3) { index ->
            val delay = index * 200
            val ringScale by infiniteTransition.animateFloat(
                initialValue = 1f,
                targetValue = 1.5f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, delayMillis = delay, easing = EaseOut),
                    repeatMode = RepeatMode.Restart
                ),
                label = "ring_scale_$index"
            )
            
            val ringAlpha by infiniteTransition.animateFloat(
                initialValue = 0.6f,
                targetValue = 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, delayMillis = delay, easing = EaseOut),
                    repeatMode = RepeatMode.Restart
                ),
                label = "ring_alpha_$index"
            )

            if (voiceState == VoiceState.LISTENING || voiceState == VoiceState.SPEAKING) {
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .scale(ringScale)
                        .clip(CircleShape)
                        .background(
                            personality.avatarColor.copy(alpha = ringAlpha * glowIntensity)
                        )
                )
            }
        }

        // Main avatar circle
        Box(
            modifier = Modifier
                .size(160.dp)
                .scale(if (voiceState == VoiceState.SPEAKING) pulseScale else 1f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            personality.avatarColor.copy(alpha = 0.8f),
                            personality.avatarColor.copy(alpha = 0.4f),
                            Color.Transparent
                        ),
                        radius = 120f
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // Inner circle with personality initial
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                personality.avatarColor,
                                personality.avatarColor.copy(alpha = 0.7f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = personality.displayName.first().toString(),
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    color = NovaTextPrimary,
                    style = MaterialTheme.typography.displayMedium
                )
            }
        }

        // Audio visualization overlay
        if (audioData.isActive && audioData.amplitude > 0) {
            Canvas(
                modifier = Modifier.size(180.dp)
            ) {
                drawAudioVisualization(
                    audioData = audioData,
                    color = personality.avatarColor,
                    glowIntensity = glowIntensity
                )
            }
        }

        // Processing spinner overlay
        if (voiceState == VoiceState.PROCESSING) {
            Canvas(
                modifier = Modifier
                    .size(200.dp)
                    .graphicsLayer { rotationZ = rotation }
            ) {
                drawProcessingSpinner(
                    color = personality.avatarColor,
                    alpha = glowIntensity
                )
            }
        }
    }
}

private fun DrawScope.drawAudioVisualization(
    audioData: AudioVisualizationData,
    color: Color,
    glowIntensity: Float
) {
    val center = Offset(size.width / 2, size.height / 2)
    val radius = size.minDimension / 2 * 0.9f
    
    // Draw audio bars around the circle
    val barCount = 32
    val angleStep = 360f / barCount
    
    for (i in 0 until barCount) {
        val angle = i * angleStep
        val barHeight = (audioData.amplitude * 20f + 10f) * glowIntensity
        
        val startRadius = radius - barHeight / 2
        val endRadius = radius + barHeight / 2
        
        val startX = center.x + cos(Math.toRadians(angle.toDouble())).toFloat() * startRadius
        val startY = center.y + sin(Math.toRadians(angle.toDouble())).toFloat() * startRadius
        val endX = center.x + cos(Math.toRadians(angle.toDouble())).toFloat() * endRadius
        val endY = center.y + sin(Math.toRadians(angle.toDouble())).toFloat() * endRadius
        
        drawLine(
            color = color.copy(alpha = glowIntensity),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawProcessingSpinner(
    color: Color,
    alpha: Float
) {
    val center = Offset(size.width / 2, size.height / 2)
    val radius = size.minDimension / 2 * 0.95f
    
    // Draw spinning dots
    val dotCount = 8
    val angleStep = 360f / dotCount
    
    for (i in 0 until dotCount) {
        val angle = i * angleStep
        val dotAlpha = alpha * (1f - i.toFloat() / dotCount)
        
        val x = center.x + cos(Math.toRadians(angle.toDouble())).toFloat() * radius
        val y = center.y + sin(Math.toRadians(angle.toDouble())).toFloat() * radius
        
        drawCircle(
            color = color.copy(alpha = dotAlpha),
            radius = 6.dp.toPx(),
            center = Offset(x, y)
        )
    }
}
