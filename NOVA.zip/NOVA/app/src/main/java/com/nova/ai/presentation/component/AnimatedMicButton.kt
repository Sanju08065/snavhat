package com.nova.ai.presentation.component

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.nova.ai.data.model.VoiceState
import com.nova.ai.presentation.theme.*

@Composable
fun AnimatedMicButton(
    voiceState: VoiceState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hapticFeedback = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    
    val infiniteTransition = rememberInfiniteTransition(label = "mic_button_animation")
    
    // Pulsing animation when listening
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    
    // Ripple effect animation
    val rippleScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseOut),
            repeatMode = RepeatMode.Restart
        ),
        label = "ripple_scale"
    )
    
    val rippleAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseOut),
            repeatMode = RepeatMode.Restart
        ),
        label = "ripple_alpha"
    )
    
    // Button color animation
    val buttonColor by animateColorAsState(
        targetValue = when (voiceState) {
            VoiceState.LISTENING -> NovaNeonBlue
            VoiceState.PROCESSING -> NovaNeonPurple
            VoiceState.SPEAKING -> NovaNeonPink
            VoiceState.ERROR -> NovaError
            else -> NovaGray
        },
        animationSpec = tween(300),
        label = "button_color"
    )
    
    // Icon selection
    val micIcon: ImageVector = when (voiceState) {
        VoiceState.LISTENING -> Icons.Default.Mic
        VoiceState.ERROR -> Icons.Default.MicOff
        else -> Icons.Default.Mic
    }

    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        // Ripple effect rings (only when listening)
        if (voiceState == VoiceState.LISTENING) {
            repeat(2) { index ->
                val delay = index * 400
                val delayedRippleScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 1.8f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, delayMillis = delay, easing = EaseOut),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "delayed_ripple_scale_$index"
                )
                
                val delayedRippleAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, delayMillis = delay, easing = EaseOut),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "delayed_ripple_alpha_$index"
                )

                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .scale(delayedRippleScale)
                        .clip(CircleShape)
                        .background(
                            buttonColor.copy(alpha = delayedRippleAlpha)
                        )
                )
            }
        }

        // Main button
        Box(
            modifier = Modifier
                .size(80.dp)
                .scale(if (voiceState == VoiceState.LISTENING) pulseScale else 1f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            buttonColor,
                            buttonColor.copy(alpha = 0.8f)
                        )
                    )
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null
                ) {
                    hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = micIcon,
                contentDescription = when (voiceState) {
                    VoiceState.LISTENING -> "Stop listening"
                    VoiceState.IDLE -> "Start listening"
                    VoiceState.PROCESSING -> "Processing"
                    VoiceState.SPEAKING -> "Speaking"
                    VoiceState.ERROR -> "Error"
                },
                tint = NovaTextPrimary,
                modifier = Modifier.size(32.dp)
            )
        }

        // Processing indicator overlay
        if (voiceState == VoiceState.PROCESSING) {
            CircularProgressIndicator(
                modifier = Modifier.size(90.dp),
                color = NovaNeonBlue,
                strokeWidth = 3.dp
            )
        }
    }
}
