package com.nova.ai.presentation.component

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.VoiceState
import com.nova.ai.presentation.theme.*
import kotlinx.coroutines.delay

@Composable
fun ConversationDisplay(
    currentInput: String,
    currentResponse: String,
    voiceState: VoiceState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Current user input
        AnimatedVisibility(
            visible = currentInput.isNotEmpty(),
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = tween(300)
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { -it },
                animationSpec = tween(300)
            ) + fadeOut()
        ) {
            UserInputBubble(text = currentInput)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Current AI response with typing animation
        AnimatedVisibility(
            visible = currentResponse.isNotEmpty(),
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = tween(300)
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(300)
            ) + fadeOut()
        ) {
            AIResponseBubble(
                text = currentResponse,
                isTyping = voiceState == VoiceState.PROCESSING
            )
        }

        // Voice state indicator
        VoiceStateIndicator(voiceState = voiceState)
    }
}

@Composable
private fun UserInputBubble(
    text: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(0.85f),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = NovaGray.copy(alpha = 0.8f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(16.dp),
            color = NovaTextPrimary,
            fontSize = 16.sp,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Start
        )
    }
}

@Composable
private fun AIResponseBubble(
    text: String,
    isTyping: Boolean,
    modifier: Modifier = Modifier
) {
    var displayedText by remember(text) { mutableStateOf("") }
    
    // Typing animation effect
    LaunchedEffect(text, isTyping) {
        if (text.isNotEmpty() && !isTyping) {
            displayedText = ""
            text.forEachIndexed { index, char ->
                delay(30) // Typing speed
                displayedText = text.substring(0, index + 1)
            }
        } else if (isTyping) {
            displayedText = ""
        } else {
            displayedText = text
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(0.85f),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = NovaNeonBlue.copy(alpha = 0.1f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            NovaNeonBlue.copy(alpha = 0.1f),
                            NovaNeonPurple.copy(alpha = 0.1f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Row {
                Text(
                    text = displayedText,
                    color = NovaTextPrimary,
                    fontSize = 16.sp,
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.weight(1f)
                )
                
                // Typing cursor
                if (isTyping || displayedText.length < text.length) {
                    TypingCursor()
                }
            }
        }
    }
}

@Composable
private fun TypingCursor() {
    val infiniteTransition = rememberInfiniteTransition(label = "typing_cursor")
    
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursor_alpha"
    )

    Text(
        text = "|",
        color = NovaNeonBlue.copy(alpha = alpha),
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun VoiceStateIndicator(
    voiceState: VoiceState,
    modifier: Modifier = Modifier
) {
    val stateText = when (voiceState) {
        VoiceState.LISTENING -> "Listening..."
        VoiceState.PROCESSING -> "Thinking..."
        VoiceState.SPEAKING -> "Speaking..."
        VoiceState.ERROR -> "Error occurred"
        else -> ""
    }
    
    val stateColor = when (voiceState) {
        VoiceState.LISTENING -> NovaNeonGreen
        VoiceState.PROCESSING -> NovaNeonPurple
        VoiceState.SPEAKING -> NovaNeonBlue
        VoiceState.ERROR -> NovaError
        else -> NovaTextSecondary
    }

    AnimatedVisibility(
        visible = stateText.isNotEmpty(),
        enter = fadeIn() + scaleIn(),
        exit = fadeOut() + scaleOut()
    ) {
        Row(
            modifier = modifier.padding(top = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Animated dots for processing states
            if (voiceState == VoiceState.PROCESSING || voiceState == VoiceState.LISTENING) {
                AnimatedDots(color = stateColor)
            }
            
            Text(
                text = stateText,
                color = stateColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun AnimatedDots(
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "animated_dots")
    
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        repeat(3) { index ->
            val alpha by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, delayMillis = index * 200),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dot_alpha_$index"
            )
            
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(color.copy(alpha = alpha))
            )
        }
    }
}
