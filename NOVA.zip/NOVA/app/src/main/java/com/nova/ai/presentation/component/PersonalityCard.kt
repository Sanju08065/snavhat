package com.nova.ai.presentation.component

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.Personality
import com.nova.ai.data.model.VoiceState
import com.nova.ai.data.model.AudioVisualizationData
import com.nova.ai.presentation.theme.*

@Composable
fun PersonalityCard(
    personality: Personality,
    isSelected: Boolean,
    onSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hapticFeedback = LocalHapticFeedback.current
    
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.05f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "card_scale"
    )
    
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) personality.avatarColor else NovaGray,
        animationSpec = tween(300),
        label = "border_color"
    )

    Card(
        modifier = modifier
            .scale(scale)
            .clickable {
                hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
                onSelected()
            },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                personality.avatarColor.copy(alpha = 0.1f)
            } else {
                NovaGray.copy(alpha = 0.3f)
            }
        ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) 8.dp else 4.dp
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 2.dp,
                    color = borderColor,
                    shape = RoundedCornerShape(20.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Mini avatar
                MiniAvatar(
                    personality = personality,
                    isSelected = isSelected
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = personality.displayName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) personality.avatarColor else NovaTextPrimary,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = personality.description,
                    fontSize = 14.sp,
                    color = NovaTextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Voice characteristics
                VoiceCharacteristics(
                    personality = personality,
                    isSelected = isSelected
                )
            }
        }
    }
}

@Composable
private fun MiniAvatar(
    personality: Personality,
    isSelected: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mini_avatar")
    
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Box(
        modifier = Modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        // Glow effect when selected
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(45.dp))
                    .background(
                        personality.avatarColor.copy(alpha = glowAlpha * 0.3f)
                    )
            )
        }
        
        // Main avatar circle
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(40.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            personality.avatarColor,
                            personality.avatarColor.copy(alpha = 0.7f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = personality.displayName.first().toString(),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = NovaTextPrimary
            )
        }
    }
}

@Composable
private fun VoiceCharacteristics(
    personality: Personality,
    isSelected: Boolean
) {
    val characteristics = when (personality) {
        Personality.TOKYO -> listOf("Warm", "Empathetic", "Gentle")
        Personality.TORONTO -> listOf("Confident", "Direct", "Professional")
    }
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        characteristics.forEach { characteristic ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSelected) {
                            personality.avatarColor.copy(alpha = 0.2f)
                        } else {
                            NovaGray.copy(alpha = 0.5f)
                        }
                    )
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text(
                    text = characteristic,
                    fontSize = 12.sp,
                    color = if (isSelected) personality.avatarColor else NovaTextSecondary,
                    fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal
                )
            }
        }
    }
}
