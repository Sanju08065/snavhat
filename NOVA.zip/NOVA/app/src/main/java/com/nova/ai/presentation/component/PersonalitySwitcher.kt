package com.nova.ai.presentation.component

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.Personality
import com.nova.ai.presentation.theme.*

@Composable
fun PersonalitySwitcher(
    currentPersonality: Personality,
    onSwitch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hapticFeedback = LocalHapticFeedback.current
    
    val switchAnimation by animateFloatAsState(
        targetValue = if (currentPersonality == Personality.TOKYO) 0f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "personality_switch"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(25.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        NovaGray.copy(alpha = 0.8f),
                        NovaLightGray.copy(alpha = 0.8f)
                    )
                )
            )
            .clickable {
                hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
                onSwitch()
            }
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Tokyo Option
        PersonalityOption(
            personality = Personality.TOKYO,
            isSelected = currentPersonality == Personality.TOKYO,
            animationProgress = 1f - switchAnimation
        )
        
        // Toronto Option
        PersonalityOption(
            personality = Personality.TORONTO,
            isSelected = currentPersonality == Personality.TORONTO,
            animationProgress = switchAnimation
        )
    }
}

@Composable
private fun PersonalityOption(
    personality: Personality,
    isSelected: Boolean,
    animationProgress: Float,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1f else 0.9f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "personality_scale"
    )
    
    val backgroundColor = if (isSelected) {
        personality.avatarColor
    } else {
        NovaGray.copy(alpha = 0.3f)
    }

    Box(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(20.dp))
            .background(backgroundColor)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = personality.displayName,
            fontSize = 14.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) NovaTextPrimary else NovaTextSecondary,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
fun WakeWordIndicator(
    state: com.nova.ai.data.model.WakeWordState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wake_word_indicator")
    
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )
    
    val indicatorColor = when (state) {
        com.nova.ai.data.model.WakeWordState.LISTENING -> NovaNeonGreen
        com.nova.ai.data.model.WakeWordState.DETECTED -> NovaNeonBlue
        com.nova.ai.data.model.WakeWordState.ERROR -> NovaError
        else -> NovaGray
    }
    
    val statusText = when (state) {
        com.nova.ai.data.model.WakeWordState.LISTENING -> "NOVA"
        com.nova.ai.data.model.WakeWordState.DETECTED -> "DETECTED"
        com.nova.ai.data.model.WakeWordState.ERROR -> "ERROR"
        else -> "OFFLINE"
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Status dot
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(
                    indicatorColor.copy(
                        alpha = if (state == com.nova.ai.data.model.WakeWordState.LISTENING) pulseAlpha else 1f
                    )
                )
        )
        
        // Status text
        Text(
            text = statusText,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = indicatorColor,
            style = MaterialTheme.typography.labelMedium
        )
    }
}
