package com.nova.ai.presentation.component

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.nova.ai.data.model.AudioVisualizationData
import com.nova.ai.presentation.theme.NovaNeonBlue
import kotlin.math.*
import kotlin.random.Random

@Composable
fun VoiceVisualizer(
    audioData: AudioVisualizationData,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 32,
    color: Color = NovaNeonBlue
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_visualizer")
    
    // Generate animated bar heights
    val animatedBars = remember { mutableStateListOf<Float>() }
    
    // Initialize bars
    LaunchedEffect(barCount) {
        animatedBars.clear()
        repeat(barCount) {
            animatedBars.add(0.1f)
        }
    }
    
    // Update bars based on audio data or generate random animation
    LaunchedEffect(isActive, audioData.amplitude) {
        if (isActive) {
            // Use real audio data if available, otherwise simulate
            val amplitude = if (audioData.amplitude > 0) {
                audioData.amplitude / 100f // Normalize
            } else {
                // Generate simulated audio visualization
                Random.nextFloat() * 0.8f + 0.2f
            }
            
            // Update bars with some randomness for visual appeal
            for (i in animatedBars.indices) {
                val variation = Random.nextFloat() * 0.4f + 0.8f
                animatedBars[i] = (amplitude * variation).coerceIn(0.1f, 1f)
            }
        } else {
            // Fade out bars when not active
            for (i in animatedBars.indices) {
                animatedBars[i] = animatedBars[i] * 0.9f
            }
        }
    }
    
    // Continuous animation when active
    LaunchedEffect(isActive) {
        while (isActive) {
            kotlinx.coroutines.delay(50) // Update every 50ms
            
            // Add wave-like motion to bars
            for (i in animatedBars.indices) {
                val waveOffset = sin((System.currentTimeMillis() / 100.0 + i * 0.5)) * 0.3f
                val baseHeight = if (audioData.amplitude > 0) {
                    audioData.amplitude / 100f
                } else {
                    Random.nextFloat() * 0.6f + 0.2f
                }
                
                animatedBars[i] = (baseHeight + waveOffset).coerceIn(0.1f, 1f)
            }
        }
    }

    Canvas(
        modifier = modifier.fillMaxWidth()
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height
        val barWidth = canvasWidth / (barCount * 1.5f)
        val barSpacing = barWidth * 0.5f
        
        for (i in 0 until barCount) {
            val barHeight = animatedBars.getOrElse(i) { 0.1f } * canvasHeight
            val x = i * (barWidth + barSpacing) + barWidth / 2
            
            // Create gradient effect from center
            val distanceFromCenter = abs(i - barCount / 2f) / (barCount / 2f)
            val alpha = (1f - distanceFromCenter * 0.5f).coerceIn(0.3f, 1f)
            
            drawLine(
                color = color.copy(alpha = alpha),
                start = Offset(x, canvasHeight / 2 + barHeight / 2),
                end = Offset(x, canvasHeight / 2 - barHeight / 2),
                strokeWidth = barWidth,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun CircularVoiceVisualizer(
    audioData: AudioVisualizationData,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 24,
    color: Color = NovaNeonBlue
) {
    val infiniteTransition = rememberInfiniteTransition(label = "circular_voice_visualizer")
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    val animatedBars = remember { mutableStateListOf<Float>() }
    
    LaunchedEffect(barCount) {
        animatedBars.clear()
        repeat(barCount) {
            animatedBars.add(0.2f)
        }
    }
    
    LaunchedEffect(isActive) {
        while (isActive) {
            kotlinx.coroutines.delay(80)
            
            for (i in animatedBars.indices) {
                val waveOffset = sin((System.currentTimeMillis() / 150.0 + i * 0.8)) * 0.4f
                val baseHeight = if (audioData.amplitude > 0) {
                    audioData.amplitude / 80f
                } else {
                    Random.nextFloat() * 0.7f + 0.3f
                }
                
                animatedBars[i] = (baseHeight + waveOffset).coerceIn(0.2f, 1f)
            }
        }
    }

    Canvas(
        modifier = modifier.size(120.dp)
    ) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = size.minDimension / 3
        val angleStep = 360f / barCount
        
        for (i in 0 until barCount) {
            val angle = (i * angleStep + rotation) % 360f
            val barLength = animatedBars.getOrElse(i) { 0.2f } * radius * 0.8f
            
            val startRadius = radius
            val endRadius = radius + barLength
            
            val startX = center.x + cos(Math.toRadians(angle.toDouble())).toFloat() * startRadius
            val startY = center.y + sin(Math.toRadians(angle.toDouble())).toFloat() * startRadius
            val endX = center.x + cos(Math.toRadians(angle.toDouble())).toFloat() * endRadius
            val endY = center.y + sin(Math.toRadians(angle.toDouble())).toFloat() * endRadius
            
            val alpha = if (isActive) 1f else 0.3f
            
            drawLine(
                color = color.copy(alpha = alpha),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}
