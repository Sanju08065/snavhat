package com.nova.ai.presentation.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nova.ai.presentation.screen.*
import com.nova.ai.presentation.viewmodel.MainViewModel

sealed class Screen(val route: String) {
    object Onboarding : Screen("onboarding")
    object Main : Screen("main")
    object Settings : Screen("settings")
    object ConversationHistory : Screen("conversation_history")
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NovaNavigation(
    navController: NavHostController = rememberNavController(),
    startDestination: String = Screen.Main.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            slideInHorizontally(
                initialOffsetX = { it },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        exitTransition = {
            slideOutHorizontally(
                targetOffsetX = { -it },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        },
        popEnterTransition = {
            slideInHorizontally(
                initialOffsetX = { -it },
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            slideOutHorizontally(
                targetOffsetX = { it },
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        }
    ) {
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onPersonalitySelected = { personality ->
                    // Handle personality selection
                },
                onComplete = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Main.route) {
            val viewModel: MainViewModel = hiltViewModel()
            MainScreenWithNavigation(
                viewModel = viewModel,
                onNavigateToSettings = {
                    navController.navigate(Screen.Settings.route)
                },
                onNavigateToHistory = {
                    navController.navigate(Screen.ConversationHistory.route)
                }
            )
        }

        composable(Screen.Settings.route) {
            val viewModel: MainViewModel = hiltViewModel()
            val currentPersonality by viewModel.currentPersonality.collectAsState()
            
            SettingsScreen(
                currentPersonality = currentPersonality,
                onPersonalityChanged = { personality ->
                    viewModel.switchPersonality()
                },
                onBackPressed = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.ConversationHistory.route) {
            val viewModel: MainViewModel = hiltViewModel()
            val conversationHistory by viewModel.conversationHistory.collectAsState()
            
            ConversationHistoryScreen(
                conversations = conversationHistory,
                onBackPressed = {
                    navController.popBackStack()
                },
                onClearHistory = {
                    // Handle clear history
                }
            )
        }
    }
}
