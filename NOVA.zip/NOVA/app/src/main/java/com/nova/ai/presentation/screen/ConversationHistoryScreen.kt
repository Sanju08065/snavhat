package com.nova.ai.presentation.screen

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.VoiceSession
import com.nova.ai.data.model.Personality
import com.nova.ai.presentation.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationHistoryScreen(
    conversations: List<VoiceSession>,
    onBackPressed: () -> Unit,
    onClearHistory: () -> Unit
) {
    val listState = rememberLazyListState()
    var showClearDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NovaGradientStart,
                        NovaGradientMiddle,
                        NovaGradientEnd
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top bar
            TopAppBar(
                title = {
                    Text(
                        text = "Conversation History",
                        color = NovaTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = NovaTextPrimary
                        )
                    }
                },
                actions = {
                    if (conversations.isNotEmpty()) {
                        IconButton(onClick = { showClearDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Clear History",
                                tint = NovaTextPrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = androidx.compose.ui.graphics.Color.Transparent
                )
            )

            if (conversations.isEmpty()) {
                EmptyHistoryState()
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    items(
                        items = conversations.reversed(), // Show newest first
                        key = { it.id }
                    ) { conversation ->
                        ConversationItem(
                            conversation = conversation,
                            modifier = Modifier.animateItemPlacement()
                        )
                    }
                }
            }
        }

        // Clear history dialog
        if (showClearDialog) {
            AlertDialog(
                onDismissRequest = { showClearDialog = false },
                title = {
                    Text(
                        text = "Clear History",
                        color = NovaTextPrimary
                    )
                },
                text = {
                    Text(
                        text = "Are you sure you want to clear all conversation history? This action cannot be undone.",
                        color = NovaTextSecondary
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            onClearHistory()
                            showClearDialog = false
                        }
                    ) {
                        Text(
                            text = "Clear",
                            color = NovaError
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showClearDialog = false }
                    ) {
                        Text(
                            text = "Cancel",
                            color = NovaTextSecondary
                        )
                    }
                },
                containerColor = NovaGray,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

@Composable
private fun EmptyHistoryState() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ChatBubbleOutline,
                contentDescription = null,
                tint = NovaTextSecondary,
                modifier = Modifier.size(64.dp)
            )
            
            Text(
                text = "No Conversations Yet",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = NovaTextPrimary
            )
            
            Text(
                text = "Start talking to Nova to see your conversation history here",
                fontSize = 14.sp,
                color = NovaTextSecondary
            )
        }
    }
}

@Composable
private fun ConversationItem(
    conversation: VoiceSession,
    modifier: Modifier = Modifier
) {
    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    val formattedDate = remember(conversation.timestamp) {
        dateFormatter.format(Date(conversation.timestamp))
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = NovaGray.copy(alpha = 0.8f)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header with personality and timestamp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PersonalityBadge(personality = conversation.personality)
                
                Text(
                    text = formattedDate,
                    fontSize = 12.sp,
                    color = NovaTextSecondary
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // User input
            if (conversation.userInput.isNotEmpty()) {
                MessageBubble(
                    text = conversation.userInput,
                    isUser = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            // AI response
            if (conversation.aiResponse.isNotEmpty()) {
                MessageBubble(
                    text = conversation.aiResponse,
                    isUser = false,
                    personality = conversation.personality
                )
            }
            
            // Action executed indicator
            conversation.actionExecuted?.let { action ->
                Spacer(modifier = Modifier.height(8.dp))
                ActionExecutedBadge(action = action)
            }
        }
    }
}

@Composable
private fun PersonalityBadge(personality: Personality) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(personality.avatarColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = personality.displayName.first().toString(),
                color = NovaTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        Text(
            text = personality.displayName,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = personality.avatarColor
        )
    }
}

@Composable
private fun MessageBubble(
    text: String,
    isUser: Boolean,
    personality: Personality? = null
) {
    val backgroundColor = if (isUser) {
        NovaLightGray.copy(alpha = 0.6f)
    } else {
        personality?.avatarColor?.copy(alpha = 0.1f) ?: NovaNeonBlue.copy(alpha = 0.1f)
    }
    
    val textColor = if (isUser) NovaTextPrimary else NovaTextPrimary

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(backgroundColor)
                .padding(12.dp)
        ) {
            Text(
                text = text,
                color = textColor,
                fontSize = 14.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun ActionExecutedBadge(action: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(NovaNeonGreen.copy(alpha = 0.2f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = NovaNeonGreen,
                    modifier = Modifier.size(16.dp)
                )
                
                Text(
                    text = "Action: $action",
                    fontSize = 12.sp,
                    color = NovaNeonGreen,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
