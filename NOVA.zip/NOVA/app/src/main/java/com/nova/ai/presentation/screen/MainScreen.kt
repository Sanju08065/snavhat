package com.nova.ai.presentation.screen

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.data.model.*
import com.nova.ai.presentation.component.AnimatedAvatar
import com.nova.ai.presentation.component.AnimatedMicButton
import com.nova.ai.presentation.component.ConversationDisplay
import com.nova.ai.presentation.component.PersonalitySwitcher
import com.nova.ai.presentation.component.VoiceVisualizer
import com.nova.ai.presentation.component.WakeWordIndicator

import com.nova.ai.presentation.theme.*
import com.nova.ai.presentation.viewmodel.MainViewModel

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentPersonality by viewModel.currentPersonality.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val conversationHistory by viewModel.conversationHistory.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NovaGradientStart,
                        NovaGradientMiddle,
                        NovaGradientEnd
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Status Bar
            TopStatusBar(
                personality = currentPersonality,
                wakeWordState = uiState.wakeWordState,
                onPersonalitySwitch = { viewModel.switchPersonality() }
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Avatar Section
            AnimatedAvatar(
                personality = currentPersonality,
                voiceState = uiState.voiceState,
                audioData = uiState.audioData
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Conversation Display
            ConversationDisplay(
                currentInput = uiState.currentUserInput,
                currentResponse = uiState.currentAiResponse,
                voiceState = uiState.voiceState,
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Voice Visualizer
            VoiceVisualizer(
                audioData = uiState.audioData,
                isActive = isListening,
                modifier = Modifier.height(60.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Mic Button
            AnimatedMicButton(
                voiceState = uiState.voiceState,
                onClick = { viewModel.onMicButtonPressed() }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Status Text
            StatusText(
                voiceState = uiState.voiceState,
                wakeWordState = uiState.wakeWordState
            )
        }

        // Error Snackbar
        uiState.errorMessage?.let { error ->
            LaunchedEffect(error) {
                // Show error and clear after delay
                kotlinx.coroutines.delay(3000)
                viewModel.clearError()
            }
            
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaError)
            ) {
                Text(
                    text = error,
                    modifier = Modifier.padding(16.dp),
                    color = NovaTextPrimary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun TopStatusBar(
    personality: Personality,
    wakeWordState: WakeWordState,
    onPersonalitySwitch: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Wake Word Status
        WakeWordIndicator(state = wakeWordState)
        
        // Personality Switcher
        PersonalitySwitcher(
            currentPersonality = personality,
            onSwitch = onPersonalitySwitch
        )
    }
}

@Composable
private fun StatusText(
    voiceState: VoiceState,
    wakeWordState: WakeWordState
) {
    val statusText = when {
        voiceState == VoiceState.LISTENING -> "Listening..."
        voiceState == VoiceState.PROCESSING -> "Processing..."
        voiceState == VoiceState.SPEAKING -> "Speaking..."
        wakeWordState == WakeWordState.LISTENING -> "Say 'Nova' to activate"
        else -> "Tap to speak"
    }

    Text(
        text = statusText,
        style = MaterialTheme.typography.bodyMedium,
        color = NovaTextSecondary,
        textAlign = TextAlign.Center
    )
}
