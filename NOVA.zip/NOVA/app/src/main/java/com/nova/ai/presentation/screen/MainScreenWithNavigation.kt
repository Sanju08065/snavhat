package com.nova.ai.presentation.screen

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.data.model.*
import com.nova.ai.presentation.component.*
import com.nova.ai.presentation.theme.*
import com.nova.ai.presentation.viewmodel.MainViewModel

@Composable
fun MainScreenWithNavigation(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentPersonality by viewModel.currentPersonality.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val conversationHistory by viewModel.conversationHistory.collectAsStateWithLifecycle()
    
    var showQuickActions by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NovaGradientStart,
                        NovaGradientMiddle,
                        NovaGradientEnd
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Enhanced Top Status Bar
            EnhancedTopStatusBar(
                personality = currentPersonality,
                wakeWordState = uiState.wakeWordState,
                onPersonalitySwitch = { viewModel.switchPersonality() },
                onSettingsClick = onNavigateToSettings,
                onHistoryClick = onNavigateToHistory,
                conversationCount = conversationHistory.size
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Avatar Section with enhanced interactions
            EnhancedAnimatedAvatar(
                personality = currentPersonality,
                voiceState = uiState.voiceState,
                audioData = uiState.audioData,
                onLongPress = { showQuickActions = true }
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Conversation Display
            ConversationDisplay(
                currentInput = uiState.currentUserInput,
                currentResponse = uiState.currentAiResponse,
                voiceState = uiState.voiceState,
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Voice Visualizer
            VoiceVisualizer(
                audioData = uiState.audioData,
                isActive = isListening,
                modifier = Modifier.height(60.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Enhanced Mic Button with quick actions
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick action buttons
                AnimatedVisibility(
                    visible = showQuickActions,
                    enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
                    exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut()
                ) {
                    QuickActionButton(
                        icon = Icons.Default.History,
                        onClick = onNavigateToHistory,
                        contentDescription = "History"
                    )
                }

                // Main mic button
                AnimatedMicButton(
                    voiceState = uiState.voiceState,
                    onClick = { 
                        viewModel.onMicButtonPressed()
                        showQuickActions = false
                    }
                )

                AnimatedVisibility(
                    visible = showQuickActions,
                    enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                    exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
                ) {
                    QuickActionButton(
                        icon = Icons.Default.Settings,
                        onClick = onNavigateToSettings,
                        contentDescription = "Settings"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Enhanced Status Text
            EnhancedStatusText(
                voiceState = uiState.voiceState,
                wakeWordState = uiState.wakeWordState,
                showQuickActions = showQuickActions,
                onDismissQuickActions = { showQuickActions = false }
            )
        }

        // Error Snackbar
        uiState.errorMessage?.let { error ->
            LaunchedEffect(error) {
                kotlinx.coroutines.delay(3000)
                viewModel.clearError()
            }
            
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaError)
            ) {
                Text(
                    text = error,
                    modifier = Modifier.padding(16.dp),
                    color = NovaTextPrimary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun EnhancedTopStatusBar(
    personality: Personality,
    wakeWordState: WakeWordState,
    onPersonalitySwitch: () -> Unit,
    onSettingsClick: () -> Unit,
    onHistoryClick: () -> Unit,
    conversationCount: Int
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Wake Word Status
        WakeWordIndicator(state = wakeWordState)
        
        // Center - Personality Switcher
        PersonalitySwitcher(
            currentPersonality = personality,
            onSwitch = onPersonalitySwitch
        )
        
        // Right side - Navigation icons
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // History with badge
            Box {
                IconButton(onClick = onHistoryClick) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "History",
                        tint = NovaTextSecondary
                    )
                }
                
                if (conversationCount > 0) {
                    Badge(
                        modifier = Modifier.align(Alignment.TopEnd),
                        containerColor = NovaNeonBlue
                    ) {
                        Text(
                            text = conversationCount.toString(),
                            color = NovaTextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EnhancedAnimatedAvatar(
    personality: Personality,
    voiceState: VoiceState,
    audioData: AudioVisualizationData,
    onLongPress: () -> Unit
) {
    val hapticFeedback = LocalHapticFeedback.current
    
    // Add gesture detection for long press
    Box(
        modifier = Modifier.size(200.dp),
        contentAlignment = Alignment.Center
    ) {
        AnimatedAvatar(
            personality = personality,
            voiceState = voiceState,
            audioData = audioData,
            modifier = Modifier
                // Add long press gesture here if needed
        )
    }
}

@Composable
private fun QuickActionButton(
    icon: ImageVector,
    onClick: () -> Unit,
    contentDescription: String
) {
    val hapticFeedback = LocalHapticFeedback.current
    
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        NovaGray.copy(alpha = 0.8f),
                        NovaGray.copy(alpha = 0.6f)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        IconButton(
            onClick = {
                hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = NovaTextSecondary,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun EnhancedStatusText(
    voiceState: VoiceState,
    wakeWordState: WakeWordState,
    showQuickActions: Boolean,
    onDismissQuickActions: () -> Unit
) {
    val statusText = when {
        showQuickActions -> "Quick actions available"
        voiceState == VoiceState.LISTENING -> "Listening..."
        voiceState == VoiceState.PROCESSING -> "Processing..."
        voiceState == VoiceState.SPEAKING -> "Speaking..."
        wakeWordState == WakeWordState.LISTENING -> "Say 'Nova' to activate"
        else -> "Tap to speak"
    }

    // Auto-dismiss quick actions after 3 seconds
    LaunchedEffect(showQuickActions) {
        if (showQuickActions) {
            kotlinx.coroutines.delay(3000)
            onDismissQuickActions()
        }
    }

    Text(
        text = statusText,
        style = MaterialTheme.typography.bodyMedium,
        color = if (showQuickActions) NovaNeonBlue else NovaTextSecondary
    )
}
