package com.nova.ai.presentation.screen

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.Personality
import com.nova.ai.presentation.component.AnimatedAvatar
import com.nova.ai.presentation.component.PersonalityCard
import com.nova.ai.presentation.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    onPersonalitySelected: (Personality) -> Unit,
    onComplete: () -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { 3 })
    var selectedPersonality by remember { mutableStateOf<Personality?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NovaGradientStart,
                        NovaGradientMiddle,
                        NovaGradientEnd
                    )
                )
            )
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            when (page) {
                0 -> WelcomePage()
                1 -> PersonalitySelectionPage(
                    selectedPersonality = selectedPersonality,
                    onPersonalitySelected = { selectedPersonality = it }
                )
                2 -> PermissionsPage(
                    selectedPersonality = selectedPersonality,
                    onComplete = {
                        selectedPersonality?.let { onPersonalitySelected(it) }
                        onComplete()
                    }
                )
            }
        }

        // Page indicators
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(32.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            repeat(3) { index ->
                val isSelected = pagerState.currentPage == index
                Box(
                    modifier = Modifier
                        .size(if (isSelected) 12.dp else 8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isSelected) NovaNeonBlue else NovaGray
                        )
                )
            }
        }

        // Navigation buttons
        if (pagerState.currentPage < 2) {
            Button(
                onClick = {
                    if (pagerState.currentPage == 1 && selectedPersonality == null) return@Button
                    // Navigate to next page
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(32.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NovaNeonBlue
                )
            ) {
                Text("Next")
            }
        }
    }
}

@Composable
private fun WelcomePage() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Animated Nova logo
        AnimatedNovaLogo()
        
        Spacer(modifier = Modifier.height(48.dp))
        
        Text(
            text = "Welcome to Nova AI",
            style = MaterialTheme.typography.displayMedium,
            color = NovaTextPrimary,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Your intelligent voice assistant with personality",
            style = MaterialTheme.typography.bodyLarge,
            color = NovaTextSecondary,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Feature highlights
        FeatureHighlights()
    }
}

@Composable
private fun PersonalitySelectionPage(
    selectedPersonality: Personality?,
    onPersonalitySelected: (Personality) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(64.dp))
        
        Text(
            text = "Choose Your Assistant",
            style = MaterialTheme.typography.displaySmall,
            color = NovaTextPrimary,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Select a personality that matches your style",
            style = MaterialTheme.typography.bodyLarge,
            color = NovaTextSecondary,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(48.dp))
        
        // Personality cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            PersonalityCard(
                personality = Personality.TOKYO,
                isSelected = selectedPersonality == Personality.TOKYO,
                onSelected = { onPersonalitySelected(Personality.TOKYO) },
                modifier = Modifier.weight(1f)
            )
            
            PersonalityCard(
                personality = Personality.TORONTO,
                isSelected = selectedPersonality == Personality.TORONTO,
                onSelected = { onPersonalitySelected(Personality.TORONTO) },
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Preview selected personality
        selectedPersonality?.let { personality ->
            PersonalityPreview(personality = personality)
        }
    }
}

@Composable
private fun PermissionsPage(
    selectedPersonality: Personality?,
    onComplete: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(64.dp))
        
        Text(
            text = "Grant Permissions",
            style = MaterialTheme.typography.displaySmall,
            color = NovaTextPrimary,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Nova needs these permissions to assist you",
            style = MaterialTheme.typography.bodyLarge,
            color = NovaTextSecondary,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(48.dp))
        
        // Permission list
        PermissionsList()
        
        Spacer(modifier = Modifier.weight(1f))
        
        Button(
            onClick = onComplete,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = NovaNeonBlue
            ),
            shape = RoundedCornerShape(28.dp)
        ) {
            Text(
                text = "Get Started",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun AnimatedNovaLogo() {
    val infiniteTransition = rememberInfiniteTransition(label = "nova_logo")
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "logo_rotation"
    )
    
    Box(
        modifier = Modifier.size(120.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer ring
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(60.dp))
                .background(
                    Brush.sweepGradient(
                        colors = listOf(
                            NovaNeonBlue,
                            NovaNeonPurple,
                            NovaNeonPink,
                            NovaNeonBlue
                        )
                    )
                )
        )
        
        // Inner circle
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(RoundedCornerShape(50.dp))
                .background(NovaBlack),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "N",
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                color = NovaNeonBlue
            )
        }
    }
}

@Composable
private fun FeatureHighlights() {
    val features = listOf(
        "🎙️ Voice Recognition",
        "🧠 AI Conversations", 
        "📱 Smart Actions",
        "🎨 Animated Interface"
    )
    
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        features.forEach { feature ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(NovaNeonBlue)
                )
                
                Text(
                    text = feature,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NovaTextSecondary
                )
            }
        }
    }
}

@Composable
private fun PersonalityPreview(personality: Personality) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = personality.avatarColor.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = personality.description,
                style = MaterialTheme.typography.bodyMedium,
                color = NovaTextPrimary,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = personality.responseStyle,
                style = MaterialTheme.typography.bodySmall,
                color = NovaTextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun PermissionsList() {
    val permissions = listOf(
        "🎤 Microphone" to "For voice recognition and commands",
        "📞 Phone" to "To make calls when requested",
        "💬 SMS" to "To send messages when requested",
        "📍 Location" to "For location-based services",
        "🔔 Notifications" to "For background operation"
    )
    
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        permissions.forEach { (title, description) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = title.split(" ")[0],
                    fontSize = 24.sp
                )
                
                Column {
                    Text(
                        text = title.split(" ").drop(1).joinToString(" "),
                        style = MaterialTheme.typography.titleMedium,
                        color = NovaTextPrimary
                    )
                    
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = NovaTextSecondary
                    )
                }
            }
        }
    }
}
