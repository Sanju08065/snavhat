package com.nova.ai.presentation.screen

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.data.model.Personality
import com.nova.ai.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentPersonality: Personality,
    onPersonalityChanged: (Personality) -> Unit,
    onBackPressed: () -> Unit
) {
    var voiceSpeed by remember { mutableFloatStateOf(1.0f) }
    var voicePitch by remember { mutableFloatStateOf(1.0f) }
    var wakeWordEnabled by remember { mutableStateOf(true) }
    var backgroundMode by remember { mutableStateOf(true) }
    var hapticFeedback by remember { mutableStateOf(true) }
    var conversationHistory by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NovaGradientStart,
                        NovaGradientMiddle,
                        NovaGradientEnd
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top bar
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        color = NovaTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackPressed) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = NovaTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = androidx.compose.ui.graphics.Color.Transparent
                )
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    SettingsSection(title = "Personality") {
                        PersonalitySettings(
                            currentPersonality = currentPersonality,
                            onPersonalityChanged = onPersonalityChanged
                        )
                    }
                }

                item {
                    SettingsSection(title = "Voice") {
                        VoiceSettings(
                            voiceSpeed = voiceSpeed,
                            voicePitch = voicePitch,
                            onSpeedChanged = { voiceSpeed = it },
                            onPitchChanged = { voicePitch = it }
                        )
                    }
                }

                item {
                    SettingsSection(title = "Features") {
                        FeatureSettings(
                            wakeWordEnabled = wakeWordEnabled,
                            backgroundMode = backgroundMode,
                            hapticFeedback = hapticFeedback,
                            conversationHistory = conversationHistory,
                            onWakeWordChanged = { wakeWordEnabled = it },
                            onBackgroundModeChanged = { backgroundMode = it },
                            onHapticFeedbackChanged = { hapticFeedback = it },
                            onConversationHistoryChanged = { conversationHistory = it }
                        )
                    }
                }

                item {
                    SettingsSection(title = "About") {
                        AboutSettings()
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = NovaGray.copy(alpha = 0.8f)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                text = title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NovaNeonBlue
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            content()
        }
    }
}

@Composable
private fun PersonalitySettings(
    currentPersonality: Personality,
    onPersonalityChanged: (Personality) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Choose your assistant's personality",
            color = NovaTextSecondary,
            fontSize = 14.sp
        )
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PersonalityOption(
                personality = Personality.TOKYO,
                isSelected = currentPersonality == Personality.TOKYO,
                onSelected = { onPersonalityChanged(Personality.TOKYO) },
                modifier = Modifier.weight(1f)
            )
            
            PersonalityOption(
                personality = Personality.TORONTO,
                isSelected = currentPersonality == Personality.TORONTO,
                onSelected = { onPersonalityChanged(Personality.TORONTO) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun PersonalityOption(
    personality: Personality,
    isSelected: Boolean,
    onSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clickable { onSelected() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                personality.avatarColor.copy(alpha = 0.2f)
            } else {
                NovaLightGray.copy(alpha = 0.5f)
            }
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(personality.avatarColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = personality.displayName.first().toString(),
                    color = NovaTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = personality.displayName,
                color = if (isSelected) personality.avatarColor else NovaTextPrimary,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun VoiceSettings(
    voiceSpeed: Float,
    voicePitch: Float,
    onSpeedChanged: (Float) -> Unit,
    onPitchChanged: (Float) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Voice Speed
        SliderSetting(
            title = "Voice Speed",
            value = voiceSpeed,
            onValueChange = onSpeedChanged,
            valueRange = 0.5f..2.0f,
            steps = 15,
            valueFormatter = { "${(it * 100).toInt()}%" }
        )
        
        // Voice Pitch
        SliderSetting(
            title = "Voice Pitch",
            value = voicePitch,
            onValueChange = onPitchChanged,
            valueRange = 0.5f..2.0f,
            steps = 15,
            valueFormatter = { "${(it * 100).toInt()}%" }
        )
    }
}

@Composable
private fun SliderSetting(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int,
    valueFormatter: (Float) -> String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = NovaTextPrimary,
                fontSize = 16.sp
            )
            
            Text(
                text = valueFormatter(value),
                color = NovaNeonBlue,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = NovaNeonBlue,
                activeTrackColor = NovaNeonBlue,
                inactiveTrackColor = NovaGray
            )
        )
    }
}

@Composable
private fun FeatureSettings(
    wakeWordEnabled: Boolean,
    backgroundMode: Boolean,
    hapticFeedback: Boolean,
    conversationHistory: Boolean,
    onWakeWordChanged: (Boolean) -> Unit,
    onBackgroundModeChanged: (Boolean) -> Unit,
    onHapticFeedbackChanged: (Boolean) -> Unit,
    onConversationHistoryChanged: (Boolean) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SwitchSetting(
            title = "Wake Word Detection",
            subtitle = "Listen for 'Nova' to activate",
            checked = wakeWordEnabled,
            onCheckedChange = onWakeWordChanged,
            icon = Icons.Default.RecordVoiceOver
        )
        
        SwitchSetting(
            title = "Background Mode",
            subtitle = "Keep assistant active in background",
            checked = backgroundMode,
            onCheckedChange = onBackgroundModeChanged,
            icon = Icons.Default.PlayArrow
        )
        
        SwitchSetting(
            title = "Haptic Feedback",
            subtitle = "Vibrate on interactions",
            checked = hapticFeedback,
            onCheckedChange = onHapticFeedbackChanged,
            icon = Icons.Default.Vibration
        )
        
        SwitchSetting(
            title = "Conversation History",
            subtitle = "Remember previous conversations",
            checked = conversationHistory,
            onCheckedChange = onConversationHistoryChanged,
            icon = Icons.Default.History
        )
    }
}

@Composable
private fun SwitchSetting(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NovaNeonBlue,
            modifier = Modifier.size(24.dp)
        )
        
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                color = NovaTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            
            Text(
                text = subtitle,
                color = NovaTextSecondary,
                fontSize = 14.sp
            )
        }
        
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NovaNeonBlue,
                checkedTrackColor = NovaNeonBlue.copy(alpha = 0.5f),
                uncheckedThumbColor = NovaGray,
                uncheckedTrackColor = NovaGray.copy(alpha = 0.5f)
            )
        )
    }
}

@Composable
private fun AboutSettings() {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AboutItem(
            title = "Version",
            value = "1.0.0",
            icon = Icons.Default.Info
        )
        
        AboutItem(
            title = "Developer",
            value = "Nova AI Team",
            icon = Icons.Default.Code
        )
        
        AboutItem(
            title = "Privacy Policy",
            value = "View",
            icon = Icons.Default.Security,
            isClickable = true
        )
        
        AboutItem(
            title = "Terms of Service",
            value = "View",
            icon = Icons.Default.Description,
            isClickable = true
        )
    }
}

@Composable
private fun AboutItem(
    title: String,
    value: String,
    icon: ImageVector,
    isClickable: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (isClickable) {
                    Modifier.clickable { /* Handle click */ }
                } else {
                    Modifier
                }
            ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NovaNeonBlue,
            modifier = Modifier.size(24.dp)
        )
        
        Text(
            text = title,
            color = NovaTextPrimary,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        
        Text(
            text = value,
            color = if (isClickable) NovaNeonBlue else NovaTextSecondary,
            fontSize = 14.sp
        )
        
        if (isClickable) {
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = NovaTextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
