package com.nova.ai.presentation.theme

import androidx.compose.ui.graphics.Color

// Nova AI Dark Theme Colors
val NovaBlack = Color(0xFF000000)
val NovaDarkGray = Color(0xFF121212)
val NovaGray = Color(0xFF1E1E1E)
val NovaLightGray = Color(0xFF2A2A2A)

// Neon Accent Colors
val NovaNeonBlue = Color(0xFF00D4FF)
val NovaNeonPurple = Color(0xFF8B5CF6)
val NovaNeonPink = Color(0xFFFF006E)
val NovaNeonGreen = Color(0xFF00FF88)

// Gradient Colors
val NovaGradientStart = Color(0xFF1A1A2E)
val NovaGradientMiddle = Color(0xFF16213E)
val NovaGradientEnd = Color(0xFF0F3460)

// Text Colors
val NovaTextPrimary = Color(0xFFFFFFFF)
val NovaTextSecondary = Color(0xFFB0B0B0)
val NovaTextAccent = Color(0xFF00D4FF)

// Status Colors
val NovaSuccess = Color(0xFF00FF88)
val NovaWarning = Color(0xFFFFB800)
val NovaError = Color(0xFFFF4757)

// Avatar Colors
val TokyoAvatarColor = Color(0xFFFF006E)
val TorontoAvatarColor = Color(0xFF00D4FF)
