package com.nova.ai.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NovaNeonBlue,
    secondary = NovaNeonPurple,
    tertiary = NovaNeonPink,
    background = NovaBlack,
    surface = NovaDarkGray,
    surfaceVariant = NovaGray,
    onPrimary = NovaBlack,
    onSecondary = NovaBlack,
    onTertiary = NovaBlack,
    onBackground = NovaTextPrimary,
    onSurface = NovaTextPrimary,
    onSurfaceVariant = NovaTextSecondary,
    error = NovaError,
    onError = NovaTextPrimary
)

@Composable
fun NovaAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
