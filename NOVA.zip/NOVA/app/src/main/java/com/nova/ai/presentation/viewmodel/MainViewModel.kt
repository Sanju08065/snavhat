package com.nova.ai.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.core.*
import com.nova.ai.data.model.*
import com.nova.ai.data.repository.ConversationRepository
import com.nova.ai.data.repository.PreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val voiceEngine: VoiceEngine,
    private val aiProcessor: AIProcessor,
    private val actionHandler: ActionHandler,
    private val wakeWordDetector: WakeWordDetector,
    private val preferencesRepository: PreferencesRepository,
    private val conversationRepository: ConversationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    val currentPersonality: StateFlow<Personality> = preferencesRepository.personalitySettings
        .map { it.currentPersonality }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = Personality.TOKYO
        )

    val conversationHistory: StateFlow<List<VoiceSession>> = conversationRepository.conversations.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    init {
        observeVoiceEngine()
        observeWakeWordDetector()
        initializeServices()
    }

    private fun observeVoiceEngine() {
        viewModelScope.launch {
            voiceEngine.voiceState.collect { state ->
                _uiState.value = _uiState.value.copy(voiceState = state)
                _isListening.value = state == VoiceState.LISTENING
            }
        }

        viewModelScope.launch {
            voiceEngine.recognizedText.collect { text ->
                if (text.isNotEmpty()) {
                    processUserInput(text)
                }
            }
        }

        viewModelScope.launch {
            voiceEngine.audioData.collect { data ->
                _uiState.value = _uiState.value.copy(audioData = data)
            }
        }
    }

    private fun observeWakeWordDetector() {
        viewModelScope.launch {
            wakeWordDetector.wakeWordState.collect { state ->
                _uiState.value = _uiState.value.copy(wakeWordState = state)
                
                if (state == WakeWordState.DETECTED) {
                    onWakeWordDetected()
                }
            }
        }
    }

    private fun initializeServices() {
        voiceEngine.initialize()
        wakeWordDetector.initialize("fLdbYUZqUKmTh8aHkqXdTtJwpeJ2J02bbwpKdY8zS5WKAc33+X/Vvw==")

        // Start wake word listening
        wakeWordDetector.startListening {
            onWakeWordDetected()
        }
    }

    fun onMicButtonPressed() {
        when (_uiState.value.voiceState) {
            VoiceState.IDLE -> startListening()
            VoiceState.LISTENING -> stopListening()
            else -> { /* Do nothing during processing or speaking */ }
        }
    }

    fun onWakeWordDetected() {
        startListening()
    }

    private fun startListening() {
        voiceEngine.startListening()
    }

    private fun stopListening() {
        voiceEngine.stopListening()
    }

    private fun processUserInput(input: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                currentUserInput = input,
                voiceState = VoiceState.PROCESSING
            )

            // Check for smart actions first
            val smartAction = aiProcessor.analyzeForSmartAction(input)
            
            if (smartAction != null && smartAction.confidence > 0.7f) {
                executeSmartAction(smartAction, input)
            } else {
                // Process as regular conversation
                processConversation(input)
            }
        }
    }

    private suspend fun executeSmartAction(action: SmartAction, originalInput: String) {
        if (action.requiresConfirmation) {
            // Ask for confirmation
            val confirmationMessage = when (action.type) {
                ActionType.CALL -> "Do you want me to call ${action.parameters["contact"]}?"
                ActionType.MESSAGE -> "Do you want me to send a message to ${action.parameters["contact"]}?"
                else -> "Do you want me to execute this action?"
            }
            
            speakResponse(confirmationMessage)
            // In a real implementation, you'd wait for user confirmation
            // For now, we'll execute directly
        }

        val result = actionHandler.executeAction(action)
        val responseMessage = if (result.success) {
            result.message
        } else {
            "I'm sorry, I couldn't complete that action. ${result.message}"
        }

        speakResponse(responseMessage)
        addToConversationHistory(originalInput, responseMessage, action.intent)
    }

    private suspend fun processConversation(input: String) {
        val response = aiProcessor.processUserInput(input, currentPersonality.value)
        speakResponse(response)
        addToConversationHistory(input, response)
    }

    private fun speakResponse(response: String) {
        voiceEngine.speak(response, currentPersonality.value)
        _uiState.value = _uiState.value.copy(
            currentAiResponse = response,
            voiceState = VoiceState.SPEAKING
        )
    }

    private fun addToConversationHistory(
        userInput: String, 
        aiResponse: String, 
        actionExecuted: String? = null
    ) {
        val session = VoiceSession(
            id = "session_${System.currentTimeMillis()}",
            userInput = userInput,
            aiResponse = aiResponse,
            personality = currentPersonality.value,
            actionExecuted = actionExecuted
        )

        viewModelScope.launch {
            conversationRepository.saveConversation(session)
        }
    }

    fun switchPersonality() {
        viewModelScope.launch {
            val currentPersonalityValue = currentPersonality.value
            val newPersonality = if (currentPersonalityValue == Personality.TOKYO) {
                Personality.TORONTO
            } else {
                Personality.TOKYO
            }

            preferencesRepository.updatePersonality(newPersonality)
            voiceEngine.setPersonality(newPersonality)
            aiProcessor.setPersonality(newPersonality)

            val switchMessage = "Switched to ${newPersonality.displayName} personality"
            speakResponse(switchMessage)
        }
    }

    fun onPermissionDenied() {
        _uiState.value = _uiState.value.copy(
            errorMessage = "Microphone permission is required for voice assistant functionality"
        )
    }

    fun onServicesStarted() {
        _uiState.value = _uiState.value.copy(isInitialized = true)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.cleanup()
        wakeWordDetector.cleanup()
    }
}

data class MainUiState(
    val isInitialized: Boolean = false,
    val voiceState: VoiceState = VoiceState.IDLE,
    val wakeWordState: WakeWordState = WakeWordState.INACTIVE,
    val currentUserInput: String = "",
    val currentAiResponse: String = "",
    val audioData: AudioVisualizationData = AudioVisualizationData(),
    val errorMessage: String? = null
)
