package com.nova.ai.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nova.ai.MainActivity
import com.nova.ai.R
import com.nova.ai.core.WakeWordDetector
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class WakeWordService : Service() {

    @Inject
    lateinit var wakeWordDetector: WakeWordDetector

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val notificationId = 1002
    private val channelId = "nova_wake_word"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initializeWakeWordDetection()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(notificationId, createNotification())
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            channelId,
            "Nova Wake Word Detection",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Nova AI wake word detection service"
            setSound(null, null)
        }

        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Nova Wake Word")
            .setContentText("Listening for 'Nova'")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun initializeWakeWordDetection() {
        serviceScope.launch {
            // Initialize with Picovoice access key
            wakeWordDetector.initialize("fLdbYUZqUKmTh8aHkqXdTtJwpeJ2J02bbwpKdY8zS5WKAc33+X/Vvw==")

            wakeWordDetector.startListening {
                // Wake word detected - launch main activity
                val intent = Intent(this@WakeWordService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("wake_word_detected", true)
                }
                startActivity(intent)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        wakeWordDetector.cleanup()
    }
}
