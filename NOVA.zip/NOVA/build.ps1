#!/usr/bin/env pwsh

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Nova AI PowerShell Build Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Set paths
$ProjectDir = Get-Location
$AdbPath = "C:\Users\Anom\Downloads\platform-tools-latest-windows\platform-tools\adb.exe"
$AndroidStudioPath = "C:\Program Files\Android\Android Studio\bin\studio64.exe"

# Check if ADB exists
if (Test-Path $AdbPath) {
    Write-Host "✅ ADB found at: $AdbPath" -ForegroundColor Green
} else {
    Write-Host "❌ ADB not found. Please check path." -ForegroundColor Red
    exit 1
}

# Function to check devices
function Check-Devices {
    Write-Host "Checking connected devices..." -ForegroundColor Yellow
    & $AdbPath devices
}

# Function to install APK
function Install-APK {
    $ApkPath = "app\build\outputs\apk\debug\app-debug.apk"
    if (Test-Path $ApkPath) {
        Write-Host "Installing APK..." -ForegroundColor Yellow
        & $AdbPath install -r $ApkPath
        Write-Host "✅ APK installed successfully!" -ForegroundColor Green
    } else {
        Write-Host "❌ APK not found. Build the project first." -ForegroundColor Red
    }
}

# Function to start app
function Start-NovaAI {
    Write-Host "Starting Nova AI..." -ForegroundColor Yellow
    & $AdbPath shell am start -n com.nova.ai/.MainActivity
    Write-Host "✅ Nova AI started!" -ForegroundColor Green
}

# Function to open Android Studio
function Open-AndroidStudio {
    if (Test-Path $AndroidStudioPath) {
        Write-Host "Opening Android Studio..." -ForegroundColor Yellow
        Start-Process $AndroidStudioPath -ArgumentList $ProjectDir
        Write-Host "✅ Android Studio opened!" -ForegroundColor Green
    } else {
        Write-Host "❌ Android Studio not found at expected path." -ForegroundColor Red
        Write-Host "Please open Android Studio manually and open: $ProjectDir" -ForegroundColor Yellow
    }
}

# Main menu
do {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Build Options:" -ForegroundColor White
    Write-Host "1. Open in Android Studio (Recommended)" -ForegroundColor White
    Write-Host "2. Check device connection" -ForegroundColor White
    Write-Host "3. Install APK (if built)" -ForegroundColor White
    Write-Host "4. Start Nova AI app" -ForegroundColor White
    Write-Host "5. Exit" -ForegroundColor White
    Write-Host "========================================" -ForegroundColor Cyan
    
    $choice = Read-Host "Enter your choice (1-5)"
    
    switch ($choice) {
        "1" { Open-AndroidStudio }
        "2" { Check-Devices }
        "3" { Install-APK }
        "4" { Start-NovaAI }
        "5" { 
            Write-Host "Goodbye!" -ForegroundColor Green
            exit 0
        }
        default { 
            Write-Host "Invalid choice. Please enter 1-5." -ForegroundColor Red
        }
    }
} while ($choice -ne "5")
